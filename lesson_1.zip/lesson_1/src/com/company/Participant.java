package com.company;

public interface Participant {
    void run(int distance);
    void swim(int distance);
    void jump(int height);
    void printResult();
}
