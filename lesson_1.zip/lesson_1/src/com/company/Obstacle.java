package com.company;

public abstract class Obstacle {
    public abstract void doIt(Animal a);
}
